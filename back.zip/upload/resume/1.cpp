#include<bits/stdc++.h>

int main(){
    std::cout<<123<<std::endl;
    return 0 ;
}